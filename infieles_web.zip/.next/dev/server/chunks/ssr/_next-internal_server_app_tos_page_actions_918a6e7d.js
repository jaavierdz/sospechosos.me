module.exports = [
"[project]/.next-internal/server/app/tos/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_tos_page_actions_918a6e7d.js.map