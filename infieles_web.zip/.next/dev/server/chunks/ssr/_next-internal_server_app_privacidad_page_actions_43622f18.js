module.exports = [
"[project]/.next-internal/server/app/privacidad/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_privacidad_page_actions_43622f18.js.map